<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($title) ? $title : 'Практическая работа №18'; ?></title>
    <link rel="stylesheet" type="text/css" href="public/css/main.css">
</head>
<body>