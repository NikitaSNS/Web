<form method="post">
    <h2>Авторизация</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam, recusandae?</p>
    <input type="text" name="login" placeholder="Логин" required>
    <input type="password" name="password" placeholder="Пароль" required>
    <input type="submit" name="submit" value="Submit">
    <h4><a href="registration.php">Псс. Нужна регистрация?</a></h4>
</form>
